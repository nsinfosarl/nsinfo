# NSINFO FOR [DOLIBARR ERP CRM](https://www.dolibarr.org)

## Informations

- Numéro du module : 172760
- Dernière mise à jour : 04/10/2026
- Éditeur : [NSINFO](https://www.ns-info.fr)
- Thème : Eldy Menu
- Licence : GPLv3
- Disponible sur : Windows - MacOS - Linux

## Version

- Version : 23.4.0
- PHP : 5.5 - 8.3
- Compatibilité : Dolibarr 11.0.0 - 24.0.x

## Liens

- Support & Assistance : [Forum dolibarr.fr](https://dolibarr.fr) / Par mail à contact@ns-info.fr
- Nsinfo Framework : [Télécharger Nsinfo](https://www.dolistore.com/product.php?id=713)
- D'autres modules développés par NSINFO disponibles sur [Dolistore.com](https://www.dolistore.com/index.php?controller=search&orderby=position&orderway=desc&tag=&website=marketplace&search_query=NSINFO)

## Fonctionnalités

NSINFO est un Framework, librairie d’objets et fonctions de NSINFO.
Il est indispensable pour tous les modules de NSINFO

## Traduction

- Français
- Anglais

## Installation

### Méthode :

- Depuis le menu "Déployer/Installer un module externe" de Dolibarr :
- Glisser l'archive ZIP 'module_nsinfo-X.Y.Z' et cliquer sur "ENVOYER FICHIER"
- Activer le module dans la liste des Modules/Applications installés

