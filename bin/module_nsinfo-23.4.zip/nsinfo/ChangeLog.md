# CHANGELOG NSINFO FOR [DOLIBARR ERP CRM](https://www.dolibarr.org)

## 23.4.0 - 04/10/2026
- Nouveau logo du module (boule NS INFO + pièces de puzzle), aussi devant les onglets Réglages, ChangeLog et À propos

## 23.3.1 - 01/10/2026
- Réglages : option « Tout activer / tout désactiver » pour un groupe d'interrupteurs (type boolall)

## 23.3.0 - 28/09/2026
- Selecteur de tags

## 23.2.3 - 25/08/2026
- fetch_extrafield()

## 23.2.2 - 25/08/2026
- Correction PHP8

## 23.2.1 - 03/08/2026
- Forcer le CSS pour les status

## 23.2.0 - 03/08/2026
- Changement URL Ticket

## 23.1.2 - 30/07/2026
- Correction ajout  de fichier zone document (correction css)

## 23.1.1 - 21/07/2026
- Correction Warning PHP 8

## 23.1.0 - 12/07/2026
- Ajout de gestion d'import d'image

## 23.0.3 - 09/07/2026
-  Fix #20: setup.lib.php warning si picto non défini

## 23.0.2 - 09/06/2026
- Ajout type textarea2

## 23.0.1 - 14/05/2026
- Correction en lien avec le module BomPdf

## 23.0.0 - 07/05/2026
- Php8 Correction SelectDate

## 22.0.2 - 17/04/2026
- Ajout 'picto' sur 'titletab'

## 22.0.0 - 28/03/2026
- Alignement des versions Numérotation NSINFO
- Option : sep fusion de colonne (argument col = nb de colonne, title = Titre, class = 'center')

## 4.2.0 - 04/03/2026
- Correction PHP 8

## 4.1.3 - 06/02/2026
- Réglage des tableaux Colonnes 1, 2 et 3
  - ('type' => 'tabdeb', 'td1'=>70, 'td2'=>15, 'td3'=>15)

## 4.1.2 - 03/02/2026
- Ajout d'un option de saut de ligne dans les configuration type=>sep

## 4.1.1 - 02/01/2026
- Ajout d'un affichage d'unité dans les dimensions de paramétrage ('unit'=>'px')

## 4.1.0 - 21/12/2025
- Ajout d'une hidden value pour les tableaux des paramètres

## 4.0.9 - 18/12/2025
- Ajout d'une option de sélection multiple dans une liste

## 4.0.8 - 16/12/2025
- Option date dans les réglages

## 4.0.7 - 09/12/2025
- Ajout d'une traduction

## 4.0.6 - 25/11/2025
- Ajout d'un champ date dans les réglages

## 4.0.5 - 05/08/2025
- Ajout du numéro de version du Framework dans la déclaration d'incident des autres modules
- Ajout du numéro de version du Framework dans la page "A propos" des autres modules

## 4.0.4 - 25/06/2025
- Correction Bool3 (Token)

## 4.0.3 - 24/06/2025
- Ajout d'un type bool (bool3) permettant de switcher une information

## 4.0.2 - 15/06/2025
- Intégration à GitHub

## 4.0.1 - 23/05/2025
- Verif version Dolibarr pour la fonction isModEnabled

## 4.0.0 - 15/05/2025
- Création d'un réglages
- Options:
  - Afficher la version du module visible (si possible)
  - Désactiver la recherche de la version des modules

- Ajout d'une fonctionnalité permettant au module GMAO d'accèder à la partie admin avec un droit particulier

## 3.0.1 - 23/04/2025
- Ajout d'un  champ textarera pour les réglages

## 3.0.0 - 06/04/2025
- Mise à jour des info SARL
- Changement de l'icône du ChangeLog
- Modification de la partie Support
- Modification de l'A Propos (page commune des modules)

## 2.1.1
- Ajout retro fonctionnalité

## 2.1.0
- MAJ PHP 8

## 2.0.15
- Correction A propos pour Factory

## 2.0.14
- Personnalisation ChangeLog & A propos en fonction du module

## 2.0.13
- Correction Php8.2

## 2.0.12
- Menu permettant d'activer ou non des champs

## 2.0.11
- Ajout bouton modifier avec action specifique ('type' => 'rec', 'btupdate'=>'btupdate')

## 2.0.10
- Ajout de fonction au niveau de l'admin

## 2.0.9
- Intégration des spécifiques modules

## 2.0.8
- Fix Css

## 2.0.7
- Modification onglet A propos

## 2.0.6
- Réglage supplémentaire sélection de produit

## 2.0.5
- Réglage entrepot

## 2.0.4
- Ajout de fonction de gestion de mail

## 2.0.3
-Ajout des fonctions de dumpn vardtest et var2d si variables divers NSINFODEBBUG = 1
dol_include_once('/nsinfo/lib/phpversif.lib.php');

## 2.0.2
- ajout d'une fonction de participation à l'à propos "NSINFOAboutDesc5"

## 2.0.1
- Ajout d'une liste "selliststring" traité en chaine

## 2.0.0
- Mise à jour pour Php8

## 1.1.10
- Ajout d'un filtre complémentaire sur liste des produits

## 1.1.9
- Ajout Champ password
- Modification du lien vers les documentations

## 1.1.8
- ajout de la liste des projets

## 1.1.7
- Suppression des appel $conf->global

## 1.1.6
- Ajout d'une sélection de produit

## 1.1.5
- Correction de la sélection par liste

## 1.1.4
- Correction de warning PHP 8

## 1.1.3
- Intégration CSS

## 1.1.2
- Ajout d'une sélection de société

## 1.1.1
- Ajout d'une sélection d'utilisateur

## 1.1.0
- PHP8

## 1.0.14
- Ajout de la selection d'un entrepôt

## 1.0.13
- Ajout fonction d'appel aux constantes

## 1.0.12
- Ajout de lien dans le Setup
- Fonction de gestion des couleurs (setColorTxtDpp, setColorDrawDpp)

## 1.0.11
- Permet de mettre de l'HTML dans les traductions des options

## 1.0.9
- Correction CSRF Option ON/OFF

## 1.0.8
- Ajout de l'accès aux incidents depuis la page "A Propos"

## 1.0.7
- Ajout du suivi de version liée au Dolistore
- Ajout ChangeLog

## 1.0.6
- Ajout de champs de type DolEditor

## 1.0.3
- Ajout d'une fonction de gestion des listes

## 1.0.2
- bibliothéque de mise en forme des réglages de module

## 1.0.0
- Initial version
